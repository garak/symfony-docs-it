Contribuire al codice
=====================

.. toctree::
    :maxdepth: 2

    bugs
    patches
    security
    tests
    standards
    conventions
    license
